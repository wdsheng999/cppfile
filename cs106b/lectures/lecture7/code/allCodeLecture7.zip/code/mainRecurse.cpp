// To compile:
// gcc -g mainRecurse.cpp -o mainRecurse
//
// To run:
// ./mainRecurse
//
int main() {
    main();
    return 0;
}

